$(document).ready(function() {
	
		$( "<span id='userSpan'>Username Message</span>").insertAfter( "#username" );
		$( "<span id='passSpan'>Password Message</span>" ).insertAfter( "#password" );
		$( "<span id='emailSpan'>Email Message</span>" ).insertAfter( "#email" );
		document.getElementById("userSpan").style.visibility="hidden";
		document.getElementById("passSpan").style.visibility="hidden";
		document.getElementById("emailSpan").style.visibility="hidden";
		
		$("#username").focus(function(){
			$("#userSpan").addClass("info");
			document.getElementById("userSpan").innerHTML="infoMessage";
			document.getElementById("userSpan").style.visibility="visible";
		});
		
		$("#password").focus(function(){
			$("#passSpan").addClass("info");
			document.getElementById("passSpan").innerHTML="infoMessage";
			document.getElementById("passSpan").style.visibility="visible";
		});
		
		$("#email").focus(function(){
			$("#emailSpan").addClass("info");
			document.getElementById("emailSpan").innerHTML="infoMessage";
			document.getElementById("emailSpan").style.visibility="visible";
		});
		
		$("#username").focusout(function(){
			var VAL = this.value;
			var regex = new RegExp("^[a-zA-Z0-9]+$");
			if(regex.test(VAL))
			{
				$("#userSpan").removeClass("info");
				$("#userSpan").addClass("ok");
				document.getElementById("userSpan").innerHTML="OK"; 
					
				document.getElementById("userSpan").style.visibility = "visible";
			}
			else if(VAL=="")
			{
				document.getElementById("userSpan").style.visibility = "hidden";
			   
			}
			else if(!regex.test(VAL))
			{
				$("#userSpan").removeClass("info");
				$("#userSpan").addClass("error");
				document.getElementById("userSpan").innerHTML="Error";
					
				document.getElementById("userSpan").style.visibility = "visible";
			}
		});
		
		$("#password").focusout(function(){
			var VAL=this.value;
			if(VAL.length>=8)
			{
				$("#passSpan").removeClass("info");
				$("#passSpan").addClass("ok");
				document.getElementById("passSpan").innerHTML="OK";
				
				document.getElementById("passSpan").style.visibility="visible";
				
			}
			else if(VAL=="")
			{
				document.getElementById("passSpan").style.visibility = "hidden";
			   
			}
			else if(VAL.length<8)
			{
				$("#passSpan").removeClass("info");
				$("#passSpan").addClass("error");
				document.getElementById("passSpan").innerHTML="Error";
					
				document.getElementById("passSpan").style.visibility = "visible";
			}
			
			
		});
		
		
		$("#email").focusout(function(){
			var VAL=this.value;
			var reg= /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
			if(reg.test(VAL))
			{
				$("#emailSpan").removeClass("info");
				$("#emailSpan").addClass("ok");
				document.getElementById("emailSpan").innerHTML="OK";
				
				document.getElementById("emailSpan").style.visibility="visible";
				
			}
			else if(VAL=="")
			{
				document.getElementById("emailSpan").style.visibility = "hidden";
			   
			}
			else if(!reg.test(VAL))
			{
				$("#emailSpan").removeClass("info");
				$("#emailSpan").addClass("error");
				document.getElementById("emailSpan").innerHTML="Error";
					
				document.getElementById("emailSpan").style.visibility = "visible";
			}
			
			
		});
		
	
});
