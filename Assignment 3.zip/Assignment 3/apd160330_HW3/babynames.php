<?php
	session_start();
	$server = "localhost";
	$user = "root";
	$password = "root";
	$db = "HW3";
	$conn = mysqli_connect($server, $user, $password, $db);
	
	if(mysqli_connect_errno()){
		echo 'Connection Failed->'.mysqli_connect_error();
		exit;
	}

	$year = intval($_POST["year"]);
	$gender = $_POST["gender"];

	if(empty($year) && !empty($gender)){
		$sql = "SELECT * FROM babynames WHERE gender='".$gender."' AND ranking<=5";
	}
	else if(empty($gender) && !empty($year)){
		$sql = "SELECT * FROM babynames WHERE year=".$year." AND ranking<=5";
	}
	else if(empty($year) && empty($gender)){
		$sql = "SELECT * FROM babynames WHERE ranking<=5";
	}
	else{
		$sql = "SELECT * FROM babynames WHERE year=".$year." AND gender='".$gender."' AND ranking<=5";
	}
	
	$result = mysqli_query($conn, $sql);

	if(!$result){
		echo "Error in MySQL Query<br>";
	}

	
	echo '<table>';
	echo "<tr>";
	echo '<td>NAME</td>';
	echo '<td>YEAR</td>';
	echo '<td>RANKING</td>';
	echo '<td>GENDER</td>';
	echo '</tr>';
	while($row = mysqli_fetch_array($result)){
		echo '<tr>';
		echo '<td>'.$row['name'].'</td>';
		echo '<td>'.$row['year'].'</td>';
		echo '<td>'.$row['ranking'].'</td>';
		echo '<td>'.$row['gender'].'</td>';
		echo '</tr>';
	}
		
	mysqli_close($conn);
	echo '</table>';
?>